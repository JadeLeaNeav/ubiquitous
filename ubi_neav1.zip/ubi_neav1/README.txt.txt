This archive contains :

	-	a folder named proteus
	-	the lab subject
	-	my lab report ubi_neav1
	-	several folder named "LABXXX"

In the proteus folder, you can find my proteus projects for the diffent tasks for the lab :

Arduino 328 1 is to used with :
	LAB12
	LAB121_blink
	LAB121_timer
	LAB122
	
Arduino 328 fade is to used with :
	LAB121_fade

Arduino 328 2 is to used with :
	LAB123

Arduino 328 3 is to used with :
	LAB131_random
	LAB131_unite
	LAB132
	LAB133
	LAB134
	LAB14
	LAB152

In the folders named "LABXXX", you can find my code in Arduino.
The number of each LAB folder matched the number of the task in the lab subject.



