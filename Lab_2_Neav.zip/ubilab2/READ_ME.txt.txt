General task :
	proteus : general task project
	arduino : lab2task1

Individual task
	proteus : individual task project
	arduino : 	input (Arduino on the top)
			output (Arduino on the bottom)